- Part 1B requires the mlxtend module to work, apart from scikit-learn

- All plots made via matplotlib are saved in saved_plots.tar.gz as pickle files.
These plots can be replotted by using the script plotagain.py
